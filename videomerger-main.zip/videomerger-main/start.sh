python3 muxbot.py
