# Video-subtitle-merger

A Simple Telegram Bot By @Tellybots to add Subtitle Files in Video

# 4 Gb Support Added

# Features
- Force Sub Button Added Soon
- Support Media Type Such as Mp4,Mkv,Webm etc 
- Auto Detect Media For Merging Subtitle
- Can add Subtitle in Any Video
- And More Features Coming Soon

# Demo 
<a href="https://t.me/tellyconverterprobot"><img src="https://telegra.ph/file/f83053e0b64f3a10a9f0a.jpg"></a>

# Deploy
Deploy Your Own Bot 💕 **Star 🎉 Fork 🍴 & Deploy**

### Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/ali-mmagneto/videomerger/blob/master/MuxBot.ipynb)


### Self Host


# License
```
MIT License

Copyright (c) 2021 sahaynitin

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

```

# Support 
<a href="https://t.me/Tellybots_support"><img src="https://img.shields.io/badge/Support_Group-2cb6e0?style=for-the-badge&logo=telegram&logoColor=white"></a> <a href="https://t.me/tellybots_4u"><img src="https://img.shields.io/badge/Updates_Channel-2cb6e0?style=for-the-badge&logo=telegram&logoColor=white"></a>


# Credit : <a href="https://github.com/pyrogram/pyrogram">
Dan For His Pyrogram Library
# Credit
<a href="https://github.com/SpEcHiDe/AnyDLBot">
Shrimadhav Uk For His Some Anydlbot Code[Just Scrapped Some Code From it]

#Credit : Remaining Credit Coming Soon
