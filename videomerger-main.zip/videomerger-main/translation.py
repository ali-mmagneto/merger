
class Translation (object):

    

    
    
    DOWNLOAD_SUCCESS = """Dosya Başarı İle İndirildi!

Geçen Süre : {} saniye."""
    FILE_SIZE_ERROR = "HATA : URL'den Dosya Boyutu Ayıklanamıyor!"
    MAX_FILE_SIZE = "Dosya boyutu 2 Gb'den büyük. Telegramın getirdiği sınır da bu!"
    LONG_CUS_FILENAME = """Sağladığınız dosya adı 60 karakterden büyük.
Lütfen daha kısa bir ad girin."""
    UNSUPPORTED_FORMAT = "Hata : Dosya Şekli {} Desteklenmiyor!"
